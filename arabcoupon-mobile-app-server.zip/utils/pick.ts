// pick fields from request query
export const pick = (obj: any, keys: any) => {
  const finalObj: any = {};

  for (const key of keys) {
    if (obj && Object.hasOwnProperty.call(obj, key)) {
      finalObj[key] = obj[key];
    }
  }
  return finalObj;
};
