const SUPER_ADMIN = "super-admin";
const ADMIN = "admin";
const MANAGER = "manager";
const INACTIVE = "inactive";

export const roles = {
  SUPER_ADMIN,
  ADMIN,
  MANAGER,
  INACTIVE,
};
