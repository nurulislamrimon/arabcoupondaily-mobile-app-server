## ArabCouponDaily

This server is for arabcoupondaily.com mobile application.
Read the [documentation](https://docs.google.com/document/d/1yLlbhDgCazG740dTKCfDG8o3a-C0qKY1PP6AauoLmFo/edit?usp=sharing) to connect with this server.

Live Preview: [link](https://arabcoupon-mobile-app-server.vercel.app/)

[Click here](https://github.com/nurulislamrimon/arabcoupondaily-mobile-app-server/blob/main/thunder-collection_ACD%20Mobile.json) to download the Thunder Client collection file. This file will help you to take a deep drive into the server. 

<br>
Technology:
<ul>
<li>  
Nodejs
</li>
<li>  
Expressjs
</li>
<li>  
Mongoose
</li>
<li>  Typescript
</li>
</ul>
Operations: \* Aggregation

Developed by Nurul Islam Rimon
