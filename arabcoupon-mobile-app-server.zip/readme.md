## ArabCouponDaily

This server is for arabcoupondaily.com mobile application.
Read the [documentation](https://docs.google.com/document/d/1yLlbhDgCazG740dTKCfDG8o3a-C0qKY1PP6AauoLmFo/edit?usp=sharing) to connect with this server.

Live Preview: [link](https://arabcoupon-mobile-app-server.vercel.app/)

Technology:

_ Nodejs
_ Expressjs
_ Mongoose
_ Typescript
Operations: \* Aggregation

Developed by Nurul Islam Rimon
