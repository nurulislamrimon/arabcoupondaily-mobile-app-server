export default interface IAdministrators {
  email: string;
  role?: string;
}
